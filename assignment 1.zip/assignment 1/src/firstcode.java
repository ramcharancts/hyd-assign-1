import javax.swing.*;


import java.awt.event.*;    
import java.io.*;   
import java.util.*; 

public class firstcode extends JFrame implements ActionListener {

	 JFrame f=new JFrame();
	 JButton b1;
	 JTextField t;
	 JLabel l;
	 JButton b2;
	 JTextArea ta;
	
	 firstcode(){
		l=new JLabel("Select Your File:");
		l.setBounds(10, 10, 90, 150);
		t=new JTextField();
		t.setBounds(120, 75, 200, 20);
		b1=new JButton("Browse");
		b1.setBounds(340, 75, 90, 20);
		b1.addActionListener(this);
		b2=new JButton("Get");
		b2.setBounds(230, 150, 60, 20);
		b2.addActionListener(this);
		ta=new JTextArea();
		ta.setBounds(50, 190, 470, 300);
		
		f.add(l);
		f.add(t);
		f.add(b1);
		f.add(b2);
		f.add(ta);
		f.setSize(600,600);
		f.setLayout(null);
		f.setVisible(true);
}
	
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource()==b1)
		{
			 JFileChooser fc=new JFileChooser();    
			 int i=fc.showOpenDialog(this);    
			 if(i==JFileChooser.APPROVE_OPTION)
			  {    
			        File f=fc.getSelectedFile();    
			        String filepath=f.getPath();
			        t.setText(filepath);
			  }
		}
		if(e.getSource()==b2)
		{
			String path=t.getText();
			
			BufferedReader br;
			try {
				br = new BufferedReader(new FileReader(path));
				String s1="";
				String s2="";
				                         
		        while((s1=br.readLine())!=null)
		        {    
		        s2+=s1+"\n";    
		        }    
		        ta.setText(s2);    
		        br.close(); 
				
				
			} catch (  IOException e1) {
				
				e1.printStackTrace();
			}
			
			
			
		}
		
	}
	
public static void main(String[] args)
{
	new firstcode();
}
}