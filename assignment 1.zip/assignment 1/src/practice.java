import javax.swing.*;


import java.awt.event.*;    
import java.io.*;   
import java.util.*; 

public class practice extends JFrame implements ActionListener {

	
	JFrame f=new JFrame();
	 JButton b1;
	 JTextField t;
	 JLabel l;
	 JButton b2;
	 JTextArea ta;
	
	 practice(){
		l=new JLabel("Select Your File:");
		l.setBounds(10, 10, 90, 150);
		t=new JTextField();
		t.setBounds(120, 75, 200, 20);
		b1=new JButton("Browse");
		b1.setBounds(340, 75, 90, 20);
		b1.addActionListener(this);
		b2=new JButton("Get");
		b2.setBounds(230, 150, 60, 20);
		b2.addActionListener(this);
		ta=new JTextArea();
		ta.setBounds(50, 190, 470, 300);
		
		f.add(l);
		f.add(t);
		f.add(b1);
		f.add(b2);
		f.add(ta);
		f.setSize(600,600);
		f.setLayout(null);
		f.setVisible(true);
}
	
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource()==b1)
		{
			 JFileChooser fc=new JFileChooser();    
			 int i=fc.showOpenDialog(this);    
			 if(i==JFileChooser.APPROVE_OPTION)
			  {    
			        File f=fc.getSelectedFile();    
			        String filepath=f.getPath();
			        t.setText(filepath);
			  }
		}
		if(e.getSource()==b2)
		{
			String path=t.getText();
			File f=new File(path);
			try {
				Scanner data=new Scanner(f);
				while(data.hasNextLine())
				{
					String txt=data.nextLine();
					ta.setText(txt);
				}
				data.close();
			} catch (FileNotFoundException e1) {
				
				e1.printStackTrace();
			}
			
			
			
		}
		
	}
	
public static void main(String[] args)
{
	new firstcode();
}
}